# LoopClick (Android source project)

This is an Android Studio starter project for the requested floating auto-clicker.

## Features in this first build
- Draggable floating control panel
- `+` adds one draggable tap marker
- START / STOP control
- Configurable click-window duration, pause duration, and tap interval
- Repeats click-window -> pause indefinitely until STOP
- Close (`×`) removes the floating panel

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android phone.

## First run
1. Open LoopClick.
2. Grant "Display over other apps".
3. Open Accessibility settings and enable "LoopClick Tap Service".
4. Return to LoopClick and tap "KONTROL PANELİNİ GÖSTER".
5. Tap `+`, move the red dot to the desired point, then START.

## Notes / limitations
- This is source code, not a prebuilt APK. The current execution environment does not include Android SDK/Gradle, so an APK could not be compiled and device-tested here.
- Android accessibility gesture dispatch is subject to OS/device restrictions and app-specific protections.
- The marker is currently a single tap point. Multi-point sequences, persistent settings screen inside the overlay, and device-specific edge-case handling can be added after testing.
- Test only in apps where automated tapping is allowed.
