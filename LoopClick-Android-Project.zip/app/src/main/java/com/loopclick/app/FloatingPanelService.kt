package com.loopclick.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.*
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var panel: View? = null
    private var target: TextView? = null
    private var running = false
    private var targetX = 500f
    private var targetY = 800f
    private var clickWindow = true
    private var cycleStarted = 0L
    private var lastTap = 0L
    private var panelParams: WindowManager.LayoutParams? = null
    private var targetParams: WindowManager.LayoutParams? = null
    private val prefs by lazy { getSharedPreferences("loopclick", MODE_PRIVATE) }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val clickSeconds = prefs.getInt("clickSeconds", 30) * 1000L
            val pauseSeconds = prefs.getInt("pauseSeconds", 10) * 1000L
            val speed = max(80, prefs.getInt("speedMs", 200)).toLong()
            val now = System.currentTimeMillis()

            if (clickWindow) {
                if (now - cycleStarted >= clickSeconds) {
                    clickWindow = false
                    cycleStarted = now
                    updatePanelText()
                } else if (now - lastTap >= speed) {
                    AutoClickAccessibilityService.instance?.tap(targetX, targetY)
                    lastTap = now
                }
            } else {
                if (now - cycleStarted >= pauseSeconds) {
                    clickWindow = true
                    cycleStarted = now
                    lastTap = 0L
                    updatePanelText()
                }
            }
            handler.postDelayed(this, 25)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        showPanel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CLOSE -> stopSelf()
            ACTION_TOGGLE -> if (running) stopLoop() else startLoop()
        }
        return START_STICKY
    }

    private fun createNotification() {
        val channelId = "loopclick_running"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "LoopClick", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("LoopClick açık")
            .setContentText("Yüzen kontrol paneli hazır")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(7, notification)
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun showPanel() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Ekran üstü izni gerekli", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(7, 5, 7, 5)
            background = rounded("#E91E293B", 28)
        }
        val grip = panelButton("⠿", "#526176") {}
        val plus = panelButton("+", "#2878E8") { addTarget() }
        val settings = panelButton("⚙", "#344256") {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        val start = panelButton("START", "#16834B") {
            if (running) stopLoop() else startLoop()
        }
        val close = panelButton("×", "#B83D3D") { stopSelf() }
        box.addView(grip); box.addView(plus); box.addView(settings); box.addView(start); box.addView(close)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 180 }
        panel = box
        panelParams = p
        wm.addView(box, p)
        grip.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = ox + (e.rawX-sx).toInt(); p.y = oy + (e.rawY-sy).toInt()
                        wm.updateViewLayout(box, p); return true
                    }
                    MotionEvent.ACTION_UP -> return true
                }
                return true
            }
        })
    }

    private fun panelButton(label: String, color: String, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(12, 12, 12, 12); background = rounded(color, 18)
            setOnClickListener { action() }
        }

    private fun addTarget() {
        if (target != null) {
            Toast.makeText(this, "Bir tıklama noktası zaten var", Toast.LENGTH_SHORT).show()
            return
        }
        val marker = TextView(this).apply {
            text = "●"; textSize = 34f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 80, 80))
            background = rounded("#55333333", 40)
        }
        val p = WindowManager.LayoutParams(
            64, 64, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 250; y = 500 }
        target = marker; targetParams = p
        wm.addView(marker, p)
        marker.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = ox + (e.rawX-sx).toInt(); p.y = oy + (e.rawY-sy).toInt()
                        wm.updateViewLayout(marker, p)
                        targetX = p.x + 32f
                        targetY = p.y + 32f
                        return true
                    }
                    MotionEvent.ACTION_UP -> return true
                }
                return true
            }
        })
        targetX = p.x + 32f; targetY = p.y + 32f
        Toast.makeText(this, "Kırmızı noktayı istediğin yere sürükle", Toast.LENGTH_LONG).show()
    }

    private fun startLoop() {
        if (AutoClickAccessibilityService.instance == null) {
            Toast.makeText(this, "Önce LoopClick erişilebilirlik iznini etkinleştir", Toast.LENGTH_LONG).show()
            return
        }
        if (target == null) addTarget()
        running = true; clickWindow = true
        cycleStarted = System.currentTimeMillis(); lastTap = 0L
        updatePanelText()
        handler.removeCallbacks(loop); handler.post(loop)
    }

    private fun stopLoop() {
        running = false; handler.removeCallbacks(loop); updatePanelText()
    }

    private fun updatePanelText() {
        val box = panel as? android.view.ViewGroup ?: return
        if (box.childCount >= 4) (box.getChildAt(3) as TextView).text =
            if (running) "STOP" else "START"
        if (box.childCount >= 4) (box.getChildAt(3) as TextView).background =
            rounded(if (running) "#B83D3D" else "#16834B", 18)
    }

    private fun rounded(color: String, radius: Int) = GradientDrawable().apply {
        setColor(Color.parseColor(color)); cornerRadius = radius.toFloat()
    }

    override fun onDestroy() {
        stopLoop()
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { target?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null; target = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_CLOSE = "com.loopclick.app.CLOSE"
        const val ACTION_TOGGLE = "com.loopclick.app.TOGGLE"
    }
}
