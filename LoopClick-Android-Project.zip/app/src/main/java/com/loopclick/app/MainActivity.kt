package com.loopclick.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var clickSeconds: EditText
    private lateinit var pauseSeconds: EditText
    private lateinit var speedMs: EditText
    private val prefs by lazy { getSharedPreferences("loopclick", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 39)
        window.navigationBarColor = Color.rgb(16, 24, 39)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(16, 24, 39))
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "LoopClick"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "Zamanlı, döngülü otomatik tıklama"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 24)
        }
        root.addView(subtitle)

        clickSeconds = addField(root, "Kaç saniye tıklasın?", prefs.getInt("clickSeconds", 30).toString())
        pauseSeconds = addField(root, "Kaç saniye beklesin?", prefs.getInt("pauseSeconds", 10).toString())
        speedMs = addField(root, "Tıklama aralığı (milisaniye)", prefs.getInt("speedMs", 200).toString())

        val note = TextView(this).apply {
            text = "Örnek: 30 sn tıkla → 10 sn bekle → tekrar et. Tıklama aralığı 200 ms ise yaklaşık saniyede 5 tıklama hedeflenir."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 12, 0, 18)
        }
        root.addView(note)

        addButton(root, "AYARLARI KAYDET", "#2878E8") { saveSettings(); toast("Ayarlar kaydedildi") }
        addButton(root, "1. EKRAN ÜSTÜ İZNİNİ AÇ", "#344256") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else toast("Ekran üstü izni zaten açık")
        }
        addButton(root, "2. TIKLAMA İZNİNİ AÇ", "#344256") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(root, "KONTROL PANELİNİ GÖSTER", "#16834B") {
            saveSettings()
            if (!Settings.canDrawOverlays(this)) {
                toast("Önce ekran üstü iznini aç")
            } else {
                startForegroundService(Intent(this, FloatingPanelService::class.java))
                toast("Panel ekrana eklendi")
            }
        }
        val warning = TextView(this).apply {
            text = "Not: Android, otomatik dokunma için LoopClick erişilebilirlik servisini ayrıca etkinleştirmeni ister. Yalnızca kendi başlattığın tıklama işlemlerinde kullan. Bazı uygulamalar otomatik tıklamayı engelleyebilir."
            textSize = 12f
            setTextColor(Color.rgb(255, 205, 120))
            setPadding(0, 18, 0, 0)
        }
        root.addView(warning)
    }

    private fun saveSettings() {
        val click = clickSeconds.text.toString().toIntOrNull()?.coerceIn(1, 86400) ?: 30
        val pause = pauseSeconds.text.toString().toIntOrNull()?.coerceIn(0, 86400) ?: 10
        val speed = speedMs.text.toString().toIntOrNull()?.coerceIn(80, 60000) ?: 200
        prefs.edit().putInt("clickSeconds", click).putInt("pauseSeconds", pause)
            .putInt("speedMs", speed).apply()
    }

    private fun addField(parent: LinearLayout, label: String, value: String): EditText {
        val tv = TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 6)
        }
        parent.addView(tv)
        return EditText(this).apply {
            setText(value)
            textSize = 16f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(39, 51, 69))
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            parent.addView(this, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 8 })
        }
    }

    private fun addButton(parent: LinearLayout, text: String, color: String, action: () -> Unit) {
        val button = Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor(color)))
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 7 })
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
